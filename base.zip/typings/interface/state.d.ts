/**
 * State interface
 */

export namespace State {
    // root state
    interface RootState {
        [key: string]: any
    }
}
