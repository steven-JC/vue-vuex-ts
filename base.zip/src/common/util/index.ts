/**
 * util
 */

import sleep from './sleep'
import deepFreeze from './deepFreeze'

export default {
    sleep,
    deepFreeze
}
