export enum Gender {
    Male = 1,
    Female,
    Ohter
}
